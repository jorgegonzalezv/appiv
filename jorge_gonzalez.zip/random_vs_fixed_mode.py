"""
Try to "classify" samples based on random chance vs always guessing
the same category.
"""
import random
from data import DataSet

##ApplyEyeMakeup, ApplyLipstick, Archery, BabyCrawling, BalanceBeam#
# fix_mode = 'ApplyLipstick'

mode_list = ['ApplyEyeMakeup', 'ApplyLipstick', 'Archery', 'BabyCrawling', 'BalanceBeam']
N = 1
res = 0
for i in range(N):
    for fix_mode in mode_list:
        print("fix_mode:",fix_mode)
        class_limit = 5  # int, can be 1-101 or None
        seq_length = 5

        data = DataSet(seq_length,class_limit)
        nb_classes = len(data.classes)

        # Try a random guess.
        nb_random_matched = 0
        nb_mode_matched = 0
        for item in data.data:
            print("item: ", item)
            choice = random.choice(data.classes)
            actual = item[1]

            if choice == actual:
                nb_random_matched += 1

            if actual == fix_mode:
                nb_mode_matched += 1

        random_accuracy = nb_random_matched / len(data.data)
        mode_accuracy = nb_mode_matched / len(data.data)
        print("Randomly matched %.2f%%" % (random_accuracy * 100))
        print("Mode matched %.2f%%" % (mode_accuracy * 100))

        res += random_accuracy

print("Average random accuracy: ", res * 100/(len(mode_list) * N)) 
